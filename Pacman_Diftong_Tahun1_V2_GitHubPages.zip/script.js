const Q=[
 {w:"gerai",d:"garai",a:"audio/gerai.mp3"},
 {w:"tupai",d:"tapai",a:"audio/tupai.mp3"},
 {w:"limau",d:"lemau",a:"audio/limau.mp3"},
 {w:"cakoi",d:"cukai",a:"audio/cakoi.mp3"},
 {w:"kaloi",d:"keloi",a:"audio/kaloi.mp3"},
 {w:"hijau",d:"hijauh",a:"audio/hijau.mp3"},
 {w:"salai",d:"sulai",a:"audio/salai.mp3"},
 {w:"kerbau",d:"kerbaw",a:"audio/kerbau.mp3"}
];
let S={name:"",i:0,score:0,pick:0,speech:0,chosen:false,spoken:false}, rec=null, listening=false;
const $=x=>document.getElementById(x);
function show(x){document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));$(x).classList.add("active")}
function normalize(s){return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z ]/g," ").replace(/\s+/g," ").trim()}
const aliases={gerai:["gerai","geray"],tupai:["tupai","tupay"],limau:["limau","limaw"],cakoi:["cakoi","cakoy"],kaloi:["kaloi","kaloy"],hijau:["hijau","hijaw"],salai:["salai","salay"],kerbau:["kerbau","kerbaw"]};
function matches(w,t){t=normalize(t);return (aliases[w]||[w]).some(a=>t===a||t.includes(a))}
function stations(){
 const pos=[[5,196],[24,196],[24,112],[48,112],[71,177],[71,260],[45,260],[88,260]];
 $("stationDots").innerHTML="";
 pos.forEach((p,i)=>{let d=document.createElement("div");d.className="dot";d.id="d"+i;d.textContent=i+1;d.style.left=p[0]+"%";d.style.top=p[1]+"px";$("stationDots").appendChild(d)})
}
function carMove(){
 const pos=[[4,198],[20,198],[20,115],[44,115],[66,182],[66,265],[40,265],[83,265]];
 $("car").style.left=pos[S.i][0]+"%";$("car").style.top=pos[S.i][1]+"px";
 document.querySelectorAll(".dot").forEach((d,j)=>{d.className="dot";if(j<S.i)d.classList.add("done");if(j===S.i)d.classList.add("current")})
}
function render(){
 let q=Q[S.i];S.chosen=false;S.spoken=false;
 $("qNo").textContent=S.i+1;$("stationHud").textContent=(S.i+1)+"/8";$("word").textContent=q.w;
 $("next").disabled=true;$("heard").textContent="";$("feedback").className="";$("feedback").textContent="";$("status").textContent="Belum membuat sebutan.";
 $("score").textContent=S.score;carMove();
 let arr=[q.w,q.d].sort(()=>Math.random()-.5);$("choices").innerHTML="";
 arr.forEach(x=>{let b=document.createElement("button");b.className="choice";b.textContent=x;b.onclick=()=>pick(b,x);$("choices").appendChild(b)});
}
function pick(btn,x){
 if(S.chosen)return;S.chosen=true;document.querySelectorAll(".choice").forEach(b=>b.disabled=true);
 if(x===Q[S.i].w){btn.classList.add("correct");S.score++;S.pick++}
 else{btn.classList.add("wrong");document.querySelectorAll(".choice").forEach(b=>{if(b.textContent===Q[S.i].w)b.classList.add("correct")})}
 $("score").textContent=S.score;$("next").disabled=!S.spoken;
}
function setupRec(){
 const R=window.SpeechRecognition||window.webkitSpeechRecognition;if(!R)return null;
 let r=new R();r.lang="ms-MY";r.continuous=false;r.interimResults=false;r.maxAlternatives=5;
 r.onstart=()=>{listening=true;$("mic").textContent="🔴 SEDANG MENDENGAR...";$("status").textContent="Sebut perkataan sekarang..."};
 r.onresult=e=>{let a=Array.from(e.results[0]).map(x=>x.transcript),best=a[0]||"";S.spoken=true;$("heard").textContent="Kamu menyebut: “"+best+"”";let ok=a.some(x=>matches(Q[S.i].w,x));$("feedback").className=ok?"good":"bad";$("feedback").textContent=ok?"✅ Syabas! Sebutan kamu betul.":"🔁 Cuba lagi. Dengar contoh sebutan dan sebut perlahan-lahan.";if(ok){S.score++;S.speech++}$("score").textContent=S.score;$("next").disabled=!S.chosen};
 r.onerror=e=>{$("status").textContent=e.error==="not-allowed"?"Mikrofon tidak dibenarkan. Sila benarkan akses mikrofon.":"Suara tidak dikesan. Cuba lagi.";};
 r.onend=()=>{listening=false;$("mic").textContent="🎤 TEKAN & SEBUT"};
 return r;
}
$("startBtn").onclick=()=>{let n=$("name").value.trim();if(!n){$("name").focus();return}S={name:n,i:0,score:0,pick:0,speech:0,chosen:false,spoken:false};stations();show("play");render();if(!rec)rec=setupRec()};
$("listen").onclick=()=>{let q=Q[S.i],au=new Audio(q.a);au.play().catch(()=>{if("speechSynthesis"in window){let u=new SpeechSynthesisUtterance(q.w);u.lang="ms-MY";u.rate=.78;speechSynthesis.speak(u)}})};
$("mic").onclick=()=>{if(!rec){$("status").textContent="Pelayar ini tidak menyokong pengecaman suara. Gunakan Chrome atau Edge.";return}if(listening){rec.stop();return}try{rec.start()}catch(e){}};
$("next").onclick=()=>{if(S.i<7){S.i++;render()}else{finish()}};
function finish(){show("result");$("resultName").textContent=S.name;$("finalScore").textContent=S.score;$("resultText").textContent=S.score>=14?"🌟 Hebat! Kamu juara diftong!":S.score>=10?"👏 Bagus! Terus berlatih.":"💪 Cuba lagi untuk menjadi lebih hebat!";$("stats").innerHTML=`<div class="stat"><b>${S.pick}/8</b>Pilihan betul</div><div class="stat"><b>${S.speech}/8</b>Sebutan betul</div><div class="stat"><b>${S.score}</b>Markah</div><div class="stat"><b>${Math.round(S.score/16*100)}%</b>Pencapaian</div>`}
$("again").onclick=()=>{show("start");$("name").value=""};
