VERSI 2 — PACMAN DIF TONG TAHUN 1

Fail utama:
- index.html
- style.css
- script.js
- audio/

Audio model:
Masukkan 8 fail MP3 dengan nama:
gerai.mp3, tupai.mp3, limau.mp3, cakoi.mp3, kaloi.mp3, hijau.mp3, salai.mp3, kerbau.mp3

Letakkan dalam folder audio.

Pengecaman suara menggunakan Web Speech API dengan bahasa ms-MY.
Paling sesuai diuji dalam Google Chrome atau Microsoft Edge dan memerlukan kebenaran mikrofon.

Markah:
- 1 markah pilihan jawapan
- 1 markah sebutan
- maksimum 16 markah

GitHub Pages:
1. Upload semua fail ke repository.
2. Settings > Pages.
3. Deploy from branch > main > root.
4. Save.
5. Buka URL GitHub Pages.
